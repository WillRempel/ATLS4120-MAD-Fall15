package com.example.willrempel.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Mainpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage);

        ImageView kitchen=(ImageView) findViewById(R.id.imageView);
     int image=R.drawable.kitchenhelp;
        kitchen.setImageResource(image);
    }


    public void gototemp(View view){
        Intent intent= new Intent(this, tempConvert.class);

        startActivity(intent);
    }


    public void gotounit(View view){
        Intent intent= new Intent(this, unit_convert.class);

        startActivity(intent);
    }

}

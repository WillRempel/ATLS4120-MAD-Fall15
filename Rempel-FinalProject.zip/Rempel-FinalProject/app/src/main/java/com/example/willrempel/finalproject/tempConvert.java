package com.example.willrempel.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class tempConvert extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_convert);






    }

    public void findTempt(View view) {

        TextView temperature = (TextView) findViewById(R.id.temp_output); //output


        EditText temp = (EditText) findViewById(R.id.temp_editText); //input



        Switch temp_switch=(Switch) findViewById(R.id.switch1); //switch
        boolean switch_temp=temp_switch.isChecked(); //swtitch


        String tempValue = temp.getText().toString();  //input

        float tempstringtofloat= Float.valueOf(tempValue); //input

        float convertedAmount1= tempstringtofloat-32;
        float convertedAmount2= convertedAmount1 * 5/9;

        if(switch_temp){
           convertedAmount1= tempstringtofloat*9/5;
           convertedAmount2= convertedAmount1 +32;
        }


        String convertedAmountstring=String.valueOf(convertedAmount2);


        temperature.setText(convertedAmountstring); //output


    }
    public void returntomain(View view){
        Intent intent= new Intent(this, Mainpage.class);

        startActivity(intent);
    }
}

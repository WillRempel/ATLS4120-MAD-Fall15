package com.example.willrempel.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class unit_convert extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_convert);
    }

    public void returntomain(View view){
        Intent intent= new Intent(this, Mainpage.class);

        startActivity(intent);

        String conversionOptions;


    }

    public void calcpandg(View view){

        TextView Converted1 = (TextView) findViewById(R.id.textView7);


        Switch pandg_switch=(Switch) findViewById(R.id.switch2);
        boolean switch_pandg=pandg_switch.isChecked();

        EditText pandg= (EditText) findViewById(R.id.pandgouput);
        String pandgValue = pandg.getText().toString();
        double pandgstringtofloat= Double.valueOf(pandgValue);

        double convertedAmount=pandgstringtofloat * 453.592;

        if (switch_pandg){
            convertedAmount=pandgstringtofloat/453.592;
        }

        String convertedAmounttoString=String.valueOf(convertedAmount);
        String rounded=String.format(convertedAmounttoString, "%.2f");

        Converted1.setText(rounded);


    }

    public void calccando(View view){

        TextView Converted2 = (TextView) findViewById(R.id.textView9);

        EditText cando= (EditText) findViewById(R.id.textView8);
        String candoValue=cando.getText().toString();
        double candostringtodouble = Double.valueOf(candoValue);

        Switch cando_switch=(Switch) findViewById(R.id.switch3);
        boolean switch_cando=cando_switch.isChecked();

        double convertedAmount2=candostringtodouble * 8;

        if (switch_cando){
            convertedAmount2=candostringtodouble / 8;
        }

        String convertedAmounttoString2=String.valueOf(convertedAmount2);

        Converted2.setText(convertedAmounttoString2);

    }



}

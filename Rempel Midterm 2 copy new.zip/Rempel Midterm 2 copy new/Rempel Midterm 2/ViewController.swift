//
//  ViewController.swift
//  Rempel Midterm 2
//
//  Created by Will Rempel on 10/29/15.
//  Copyright (c) 2015 Will Rempel. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var milesAmount: UITextField!

    @IBOutlet weak var totalCommute: UILabel!
    
    @IBOutlet weak var gasRequired: UILabel!
    
    var speed : Float=0.0
    
    @IBAction func commuteTime(sender: UIButton) {
        calculateCommute()
    }
    
    @IBOutlet weak var transportType: UIImageView!
    
    @IBOutlet weak var transportControl: UISegmentedControl!
    
    @IBAction func transportSwitch(sender: UISegmentedControl) {
       
        if transportControl.selectedSegmentIndex==0{
            speed=20
            transportType.image=UIImage(named: "car.png")
        }
        else if transportControl.selectedSegmentIndex==1{
            speed=12
            transportType.image=UIImage(named: "bus.png")
        }
        
        else if transportControl.selectedSegmentIndex==2{
            speed=10
            transportType.image=UIImage(named: "bike.png")
        }
        
    }
    
    
    func calculateCommute(){
        let miles = (milesAmount.text as NSString).floatValue
        let time = miles / speed
      
        let Formatter = NSNumberFormatter()
        println("timeFormatter")
        
        totalCommute.text=Formatter.stringFromNumber(time)
        
        
        
        let gasNeeded = miles * 0.04166666666667
        println(gasNeeded)
    
        gasRequired.text=Formatter.stringFromNumber(gasNeeded)
        
        if miles >= 50 {
            let alert=UIAlertController(title: "Heads Up", message: "Your commute is over 50 miles, bring some music", preferredStyle: UIAlertControllerStyle.Alert)
            
            let cancelAction = UIAlertAction(title: "Cancel", style:UIAlertActionStyle.Cancel, handler: nil)
            
            alert.addAction(cancelAction)
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: {
                action in self.milesAmount.text
            })
            alert.addAction(okAction)
            presentViewController(alert, animated: true, completion: nil)}
            
        }
        
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
}

    override func viewDidLoad() {
          super.viewDidLoad()
        milesAmount.delegate=self
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


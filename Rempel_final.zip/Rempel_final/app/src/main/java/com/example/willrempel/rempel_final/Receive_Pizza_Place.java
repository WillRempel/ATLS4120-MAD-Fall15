package com.example.willrempel.rempel_final;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Receive_Pizza_Place extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive__pizza__place);
    }
}

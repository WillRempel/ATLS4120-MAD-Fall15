package com.example.willrempel.rempel_final;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

public class Final extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
    }




    public void createPizza(View view){
        //private void setPizzainfo{



            String crusttype;
            String pizzaPlace;
            String pizzaPlaceURL;


            RadioGroup crust = (RadioGroup) findViewById(R.id.crust_type);

            int crust_id = crust.getCheckedRadioButtonId();
            switch (crust_id) {
                case -1:
                    crusttype = "no ";
                    break;

                case R.id.radioButton1:
                    crusttype = "thin ";
                    pizzaPlace = "Pizzeria Locale";
                    pizzaPlaceURL = "http://localeboulder.com";
                    break;

                case R.id.radioButton2:
                    crusttype = "thick ";
                    pizzaPlace = "Old Chicago";
                    pizzaPlaceURL = "http://www.oldchicago.com";
                    break;

                default:
                    crusttype = "no ";
            }


            String gluten_string = "";
            Switch gluten_switch = (Switch) findViewById(R.id.switch1);
            boolean gluten = gluten_switch.isChecked();
            if (gluten) {
                gluten_string = " and is gluten-free";
                pizzaPlace = "Beau Jo's";
                pizzaPlaceURL = "http://www.beaujos.com";
            }


            TextView pizza = (TextView) findViewById(R.id.pizzaText);
            pizza.setText("my favorite pizza has " + crusttype + "crust" + gluten_string);
        }
    //}

   // public void setPizzaPlace(String pizzaPlace){
   //   setPizzaPlace(pizzaPlace);
   // }

  //  public void setPizzaPlaceURL(String pizzaplace){
   //     setPizzaPlaceURL(pizzaplace);

    }

  //  private pizzaPlace MyPizzaPlace=new createPizza();

 //   public void findPizza(View view){
   //     myPizzaPlace.setPizzaplace





   // Intent intent = new intent(this, )


